const body = document.querySelector('.top')
body.animate([{opacity: '0'}, {opacity: '1'}], 1000)

const h3 = document.querySelector('.big')
h3.animate([{opacity: '0'}, {opacity: '1'}], 2000) 